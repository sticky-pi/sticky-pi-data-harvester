# Do not modify manually. Built automatically from ../../.env
__version__ = '1.0.0'
